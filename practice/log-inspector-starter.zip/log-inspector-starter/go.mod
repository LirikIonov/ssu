module example.com/log-inspector

go 1.26
